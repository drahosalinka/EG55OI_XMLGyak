/**
 * 
 */
/**
 * @author user
 *
 */
module DomQueryEG55OI {
	requires java.xml;
}