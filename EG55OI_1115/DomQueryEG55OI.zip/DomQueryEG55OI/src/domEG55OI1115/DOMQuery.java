package domEG55OI1115;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.util.*;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DOMQuery {
    private static final String FILENAME = "/Users/TEMP.IIT.006/Desktop/EG55OI_1115/EG55OI_orarend.xml";

    public static void main(String[] args) {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(new File(FILENAME));
            doc.getDocumentElement().normalize();

            System.out.println("Root Element: " + doc.getDocumentElement().getNodeName());
            System.out.println("------");

            // Beolvasás és kiírás a konzolra
            queryAndPrintCourses(doc);

            // Beolvasás és kiírás fájlba
            writeToFile(doc.getDocumentElement(), "result.txt");
            
            queryAndPrintInstructors(doc);
            
         // Összetett lekérdezés: Gyakorlat típusú kurzusok, Hetfo napra tervezve
            queryAndPrintPracticeCoursesOnMonday(doc);

        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
    }

    private static void queryAndPrintCourses(Document doc) {
        NodeList oraList = doc.getElementsByTagName("ora");

        System.out.print("Kurzusnév: [");
        for (int temp = 0; temp < oraList.getLength(); temp++) {
            Node node = oraList.item(temp);

            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;

                String targy = element.getElementsByTagName("targy").item(0).getTextContent();
                System.out.print(targy);

                if (temp < oraList.getLength() - 1) {
                    System.out.print(", ");
                }
            }
        }
        System.out.println("]");
    }

    private static void writeToFile(Node node, String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            writeNodeToFile(node, "", writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void writeNodeToFile(Node node, String indent, FileWriter writer) throws IOException {
        if (node.getNodeType() == Node.ELEMENT_NODE) {
            Element element = (Element) node;
            writer.write(indent + "Node Name: " + element.getNodeName() + "\n");

            if (node.hasAttributes()) {
                writer.write(indent + "Attributes: " + node.getAttributes() + "\n");
            }

            if (node.hasChildNodes()) {
                NodeList nodeList = node.getChildNodes();
                for (int i = 0; i < nodeList.getLength(); i++) {
                    Node childNode = nodeList.item(i);

                    if (childNode.getNodeType() == Node.ELEMENT_NODE) {
                        writeNodeToFile(childNode, indent + "\t", writer);
                    } else if (childNode.getNodeType() == Node.TEXT_NODE && !childNode.getNodeValue().trim().isEmpty()) {
                        writer.write(indent + "Text: " + childNode.getNodeValue().trim() + "\n");
                    }
                }
            }
        }
    }
    
    private static void queryAndPrintInstructors(Document doc) {
        Set<String> instructorsSet = new HashSet<>();

        NodeList oraList = doc.getElementsByTagName("ora");

        for (int temp = 0; temp < oraList.getLength(); temp++) {
            Node node = oraList.item(temp);

            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;

                String oktato = element.getElementsByTagName("oktato").item(0).getTextContent();
                instructorsSet.add(oktato);
            }
        }

        List<String> instructorsList = new ArrayList<>(instructorsSet);

        System.out.println("Oktatók nevei:");
        for (String instructor : instructorsList) {
            System.out.println(instructor);
        }
    }
    
    private static void queryAndPrintPracticeCoursesOnMonday(Document doc) {
        List<String> practiceCoursesOnMonday = new ArrayList<>();

        NodeList oraList = doc.getElementsByTagName("ora");

        for (int temp = 0; temp < oraList.getLength(); temp++) {
            Node node = oraList.item(temp);

            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;

                String tipus = element.getAttribute("tipus");
                NodeList idopontNodeList = element.getElementsByTagName("idopont");
                String nap = idopontNodeList.item(0).getAttributes().getNamedItem("nap").getTextContent();

                if ("gyakorlat".equals(tipus) && "Hetfo".equals(nap)) {
                    String targy = element.getElementsByTagName("targy").item(0).getTextContent();
                    practiceCoursesOnMonday.add(targy);
                }
            }
        }

        System.out.println("Gyakorlat típusú kurzusok Hetfo napra tervezve:");
        for (String course : practiceCoursesOnMonday) {
            System.out.println(course);
        }
    }
}
