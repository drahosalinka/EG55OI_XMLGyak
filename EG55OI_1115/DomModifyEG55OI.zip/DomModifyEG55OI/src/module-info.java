/**
 * 
 */
/**
 * @author user
 *
 */
module DomModifyEG55OI {
	requires java.xml;
}