package domEG55OI1115;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DomModifyEG55OI {

    private static final String FILENAME = "/Users/TEMP.IIT.006/Desktop/EG55OI_1115/EG55OI_orarend.xml";

    public static void main(String[] args) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(new File(FILENAME));

            // Módosítás
            addInstructorToCoursesWithoutInstructor(doc);
            modifyLessonTypes(doc);
            modifyInstructorForSpecificCourses(doc, "Korszeru Webtechnologiak", "Dr. Nagy Péter");


            // Kiírás a konzolra
            printDocument(doc);

            // Kiírás fájlba
            saveDocumentToFile(doc, "orarendModifyNeptunkod.xml");

        } catch (ParserConfigurationException | IOException | org.xml.sax.SAXException | TransformerException e) {
            e.printStackTrace();
        }
    }

    private static void addInstructorToCoursesWithoutInstructor(Document doc) {
        NodeList oraList = doc.getElementsByTagName("ora");

        for (int temp = 0; temp < oraList.getLength(); temp++) {
            Node node = oraList.item(temp);

            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;

                // Ellenőrzés, hogy van-e már óraadó
                NodeList oktatoNodeList = element.getElementsByTagName("oktato");
                if (oktatoNodeList.getLength() == 0) {
                    // Nincs óraadó, hozzáadunk egyet
                    Element newInstructorElement = doc.createElement("oktato");
                    newInstructorElement.appendChild(doc.createTextNode("Új Oraado"));
                    element.appendChild(newInstructorElement);
                }
            }
        }
    }
    
    private static void modifyLessonTypes(Document doc) {
        NodeList oraList = doc.getElementsByTagName("ora");

        for (int temp = 0; temp < oraList.getLength(); temp++) {
            Node node = oraList.item(temp);

            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;

                // Módosítás példája: óra típusának átváltása gyakorlatról előadásra
                element.setAttribute("tipus", "eloadas");
            }
        }
    }
    
    private static void modifyInstructorForSpecificCourses(Document doc, String szak, String newInstructor) {
        NodeList oraList = doc.getElementsByTagName("ora");

        for (int temp = 0; temp < oraList.getLength(); temp++) {
            Node node = oraList.item(temp);

            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;

                // Ellenőrizzük, hogy a kurzus a megadott szakhoz tartozik-e
                NodeList szakNodeList = element.getElementsByTagName("szak");
                if (szakNodeList.getLength() > 0 && szakNodeList.item(0).getTextContent().equals(szak)) {
                    // Módosítjuk az oktatót
                    NodeList oktatoNodeList = element.getElementsByTagName("oktato");
                    if (oktatoNodeList.getLength() > 0) {
                        oktatoNodeList.item(0).setTextContent(newInstructor);
                    }
                }
            }
        }
    }

    private static void printDocument(Document doc) {
        try {
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer transformer = tf.newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");

            // Kiírás a konzolra
            transformer.transform(new DOMSource(doc), new StreamResult(System.out));

        } catch (TransformerConfigurationException e) {
            e.printStackTrace();
        } catch (TransformerException e) {
            e.printStackTrace();
        }
    }

    private static void saveDocumentToFile(Document doc, String filename) {
        try {
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer transformer = tf.newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");

            // Kiírás fájlba
            transformer.transform(new DOMSource(doc), new StreamResult(new FileOutputStream(filename)));

        } catch (TransformerConfigurationException e) {
            e.printStackTrace();
        } catch (TransformerException | IOException e) {
            e.printStackTrace();
        }
    }
}
