package domEG55OI1108;

import java.io.File;
import java.io.IOException;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DomReadEG55OI {

	private static final String FILENAME = "/Users/TEMP.IIT.006/Desktop/EG55OI_1108/EG55OI_kurzusfelvetel.xml";

	  public static void main(String[] args) {
	      DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

	      try {
	          dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

	          
	          DocumentBuilder db = dbf.newDocumentBuilder();

	          Document doc = db.parse(new File(FILENAME));
	          doc.getDocumentElement().normalize();

	          System.out.println("Root Element :" + doc.getDocumentElement().getNodeName());
	          System.out.println("------");

	          NodeList hallgatoList = doc.getElementsByTagName("hallgato");

	          for (int temp = 0; temp < hallgatoList.getLength(); temp++) {

	              Node node = hallgatoList.item(temp);

	              if (node.getNodeType() == Node.ELEMENT_NODE) {

	                  Element element = (Element) node;

	                  String hneve = element.getElementsByTagName("hnev").item(0).getTextContent();
	                  String szulev = element.getElementsByTagName("szulev").item(0).getTextContent();

	                  NodeList szakNodeList = element.getElementsByTagName("szak");
	                  String szak = szakNodeList.item(0).getTextContent();

	                  // get salary's attribute
	                  String evf = szakNodeList.item(0).getAttributes().getNamedItem("evf").getTextContent();

	              }
	          }
	          
	          NodeList kurzusokList = doc.getElementsByTagName("kurzusok");
	          
	          for (int temp = 0; temp < kurzusokList.getLength(); temp++) {

	              Node node = kurzusokList.item(temp);

	              if (node.getNodeType() == Node.ELEMENT_NODE) {

	                  Element element = (Element) node;
	                  
	                  String id = element.getAttribute("id");
	                  String jovahagyas = element.getAttribute("jovahagyas");

	                  String kurzusnev = element.getElementsByTagName("kurzusnev").item(0).getTextContent();
	                  String kredit = element.getElementsByTagName("kredit").item(0).getTextContent();
	                  String hely = element.getElementsByTagName("hely").item(0).getTextContent();
	                  String idopont = element.getElementsByTagName("idopont").item(0).getTextContent();
	                  String oktato = element.getElementsByTagName("oktato").item(0).getTextContent();



	                  NodeList szakNodeList = element.getElementsByTagName("szak");
	                  String szak = szakNodeList.item(0).getTextContent();

	                  // get salary's attribute
	                  String evf = szakNodeList.item(0).getAttributes().getNamedItem("evf").getTextContent();

	              }
	          }
	          
	         

	      } catch (ParserConfigurationException | SAXException | IOException e) {
	          e.printStackTrace();
	      }

	  }

}
