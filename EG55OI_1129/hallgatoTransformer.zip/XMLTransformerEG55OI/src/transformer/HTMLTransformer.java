package transformer;

import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.File;
import java.io.IOException;

public class HTMLTransformer {

    public static void main(String[] args) {
        try {
            // Elérési utak
            String xmlInputPath = "path/to/hallgatoEG55OI.xml";
            String xsltPath = "path/to/hallgatoEG55OI.xsl";
            String htmlOutputPath = "path/to/hallgatoEG55OI.html";

            // XSLT transformer létrehozása
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Source xsltSource = new StreamSource(new File(xsltPath));
            Transformer transformer = transformerFactory.newTransformer(xsltSource);

            // XML forrás beolvasása
            Source xmlSource = new StreamSource(new File(xmlInputPath));

            // Kimeneti fájl beállítása
            Result outputResult = new StreamResult(new File(htmlOutputPath));

            // Átalakítás végrehajtása
            transformer.transform(xmlSource, outputResult);

            // HTML fájl megnyitása a böngészőben
            openHtmlFileInBrowser(htmlOutputPath);

        } catch (TransformerException e) {
            System.err.println("Átalakítás során hiba történt: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("Hiba történt a HTML fájl megnyitása közben: " + e.getMessage());
        }
    }

    private static void openHtmlFileInBrowser(String htmlFilePath) throws IOException {
        String os = System.getProperty("os.name").toLowerCase();

        if (os.contains("win")) {
            // Windows rendszeren
            Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + htmlFilePath);
        } else if (os.contains("nix") || os.contains("nux") || os.contains("mac")) {
            // Linux vagy macOS rendszeren
            Runtime.getRuntime().exec("xdg-open " + htmlFilePath);
        } else {
            // Nem támogatott rendszer
            System.out.println("A rendszer nem támogatott a HTML fájl megnyitásához.");
        }
    }
}
