package transformer;

import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.File;

public class XMLTransformer {

    public static void main(String[] args) {
        try {
            // Elérési utak
            String xmlInputPath = "path/to/hallgatoEG55OI.xml";
            String xsltPath = "path/to/hallgatoEG55OI.xsl";
            String xmlOutputPath = "path/to/hallgatoEG55OI.out.xml";

            // XSLT transformer létrehozása
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Source xsltSource = new StreamSource(new File(xsltPath));
            Transformer transformer = transformerFactory.newTransformer(xsltSource);

            // XML forrás beolvasása
            Source xmlSource = new StreamSource(new File(xmlInputPath));

            // Kimeneti fájl beállítása
            Result outputResult = new StreamResult(new File(xmlOutputPath));

            // Átalakítás végrehajtása
            transformer.transform(xmlSource, outputResult);

            System.out.println("Sikeres átalakítás. Az eredmény a " + xmlOutputPath + " fájlban található.");

        } catch (TransformerException e) {
            System.err.println("Átalakítás során hiba történt: " + e.getMessage());
        }
    }
}