/**
 * 
 */
/**
 * @author user
 *
 */
module XMLTransformerEG55OI {
	requires java.xml;
}