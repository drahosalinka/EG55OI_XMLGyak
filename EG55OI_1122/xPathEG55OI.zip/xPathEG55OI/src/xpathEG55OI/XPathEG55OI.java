package xpathEG55OI;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.*;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class XPathEG55OI {
    public static void main(String[] args) {
        try {
            // XML fájl beolvasása
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse("studentEG55OI.xml");

            // XPath inicializálása
            XPathFactory xPathFactory = XPathFactory.newInstance();
            XPath xpath = xPathFactory.newXPath();
            
            

            // XPath kifejezés az összes student elem kiválasztására
            /*XPathExpression expr = xpath.compile("/class/student");
            NodeList nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);*/
            
            // XPath kifejezés a kívánt student elem kiválasztására az id attribútum alapján
            /*XPathExpression expr = xpath.compile("/class/student[@id='2']");
            Node node = (Node) expr.evaluate(doc, XPathConstants.NODE);*/
            
            // XPath kifejezés az összes student elem kiválasztására
            /*XPathExpression expr = xpath.compile("//student");
            NodeList nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);*/
            
            // XPath kifejezés a második student elem kiválasztására
            /*XPathExpression expr = xpath.compile("/class/student[2]");
            Node node = (Node) expr.evaluate(doc, XPathConstants.NODE);*/
            
            // XPath kifejezés az utolsó student elem kiválasztására
            /*XPathExpression expr = xpath.compile("/class/student[last()]");
            Node node = (Node) expr.evaluate(doc, XPathConstants.NODE);*/
            
            // XPath kifejezés az utolsó előtti student elem kiválasztására
            /*XPathExpression expr = xpath.compile("/class/student[last()-1]");
            Node node = (Node) expr.evaluate(doc, XPathConstants.NODE);*/
            
            // XPath kifejezés az első két gyerek elem kiválasztására
            //XPathExpression expr = xpath.compile("/*/*[position() <= 2]");
            //NodeList nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
            
            // XPath kifejezés a class gyökérelem összes gyerek elemének kiválasztására
            /*XPathExpression expr = xpath.compile("/class/*");
            NodeList nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);*/
            
            // XPath kifejezés az összes student elem kiválasztására, amely legalább egy attribútummal rendelkezik
            /*XPathExpression expr = xpath.compile("//student[@*]");
            NodeList nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);*/
            
            // XPath kifejezés az összes elem kiválasztására
            /*XPathExpression expr = xpath.compile("//*");
            NodeList nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);*/
            
            // XPath kifejezés a class gyökérelem összes elemének kiválasztására, ahol a kor>20
            /*XPathExpression expr = xpath.compile("/class/*[kor > 20]");
            NodeList nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);*/
            
            // XPath kifejezés az összes student elem vezeteknev és keresztnev csomópontjainak kiválasztására
            XPathExpression expr = xpath.compile("//student/(vezeteknev|keresztnev)");
            NodeList nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
