/**
 * 
 */
/**
 * @author user
 *
 */
module xPathEG55OI {
	requires java.xml;
}