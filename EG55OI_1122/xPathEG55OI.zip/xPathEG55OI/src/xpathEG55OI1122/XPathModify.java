package xpathEG55OI1122;

import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.*;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XPathModify {
	
	public static void main(String[] args) {
        try {
            // XML fájl beolvasása
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse("kurzusfelvetelEG55OI.xml");

            // Módosítások elvégzése
            modifyCourseLocation(doc);
            addAttributeToCourse(doc);
            removeCourse(doc);

            // Kiírás a konzolra
            printDocument(doc);

            // Kiírás fájlba
            writeToFile(doc, "kurzusfelvetelNeptunkod1.xml");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Módosítás 1: kurzus helyének módosítása
    private static void modifyCourseLocation(Document doc) {
        try {
            XPathFactory xPathFactory = XPathFactory.newInstance();
            XPath xpath = xPathFactory.newXPath();

            // XPath kifejezés a kurzus hely módosítására
            XPathExpression expr = xpath.compile("/EG55OI_kurzusfelvetel/kurzusok/kurzus[kurzusnev='Webtechnologiak']/hely/text()");
            Node node = (Node) expr.evaluate(doc, XPathConstants.NODE);

            // Módosítás: új hely beállítása
            if (node != null) {
                node.setTextContent("D-105");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Módosítás 2: attribútum hozzáadása egy kurzushoz
    private static void addAttributeToCourse(Document doc) {
        try {
            XPathFactory xPathFactory = XPathFactory.newInstance();
            XPath xpath = xPathFactory.newXPath();

            // XPath kifejezés a kurzus kiválasztására, amelyhez attribútumot adunk
            XPathExpression expr = xpath.compile("/EG55OI_kurzusfelvetel/kurzusok/kurzus[kurzusnev='Elektronika']");
            Node node = (Node) expr.evaluate(doc, XPathConstants.NODE);

            // Módosítás: attribútum hozzáadása
            if (node != null) {
                Element kurzusElement = (Element) node;
                kurzusElement.setAttribute("ujAttributum", "ertek");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Módosítás 3: kurzus törlése
    private static void removeCourse(Document doc) {
        try {
            XPathFactory xPathFactory = XPathFactory.newInstance();
            XPath xpath = xPathFactory.newXPath();

            // XPath kifejezés a kurzus törlésére
            XPathExpression expr = xpath.compile("/EG55OI_kurzusfelvetel/kurzusok/kurzus[kurzusnev='Fizika 2']");
            Node node = (Node) expr.evaluate(doc, XPathConstants.NODE);

            // Módosítás: kurzus törlése
            if (node != null) {
                node.getParentNode().removeChild(node);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Kiíratás a konzolra
    private static void printDocument(Document doc) {
        try {
            // TransformerFactory transformerFactory = TransformerFactory.newInstance();
            // Transformer transformer = transformerFactory.newTransformer();
            // transformer.setOutputProperty(OutputKeys.INDENT, "yes");

            // StringWriter writer = new StringWriter();
            // transformer.transform(new DOMSource(doc), new StreamResult(writer));
            // System.out.println(writer.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Kiíratás fájlba
    private static void writeToFile(Document doc, String fileName) {
        try {
            // TransformerFactory transformerFactory = TransformerFactory.newInstance();
            // Transformer transformer = transformerFactory.newTransformer();
            // transformer.setOutputProperty(OutputKeys.INDENT, "yes");

            // // Kiírás a fájlba
            // File file = new File(fileName);
            // Writer writer = new FileWriter(file);
            // transformer.transform(new DOMSource(doc), new StreamResult(writer));
            // writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
